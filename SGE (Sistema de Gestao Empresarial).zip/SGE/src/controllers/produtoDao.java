/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.produtoModel;
import view.dashboard;


/**
 *
 * @author Milton Miquitaio
 */
public class produtoDao {
    
    
    public void cadastrarProduto(produtoModel produto){
    
    String sql = "INSERT INTO produto(preco,comissao,produto,quantidade) VALUES (?,?,?,?)";
    
    
        try {
            Connection conn = new ClassConexao().conectaBD();
            PreparedStatement ps = conn.prepareStatement(sql);
            
            ps.setFloat(1, produto.getPreco());
            ps.setInt(2, produto.getComissao());
            ps.setString(3, produto.getNome());
            ps.setInt(4, produto.getQuantidade());
            
            ps.execute();
            
            JOptionPane.showMessageDialog(null, "produto cadastrado com sucesso");
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar o produto.   ERRO: " + e);
        }
    
    
    
    
    
    }
    
    
    
    
     public static void ler_dados(){
        
     DefaultTableModel model = (DefaultTableModel) dashboard.tabProduto.getModel();
     model.setNumRows(0);
     try{
           
           Connection conn = null;
           conn = new ClassConexao().conectaBD();
           String sql = "SELECT * FROM produto;";

            PreparedStatement ps = null ;
          
            ps = conn.prepareStatement(sql);
          
            ResultSet res = null;
            
            res = ps.executeQuery();
    
            ResultSetMetaData rsmd = res.getMetaData();
            int qtdCol = rsmd.getColumnCount();

            while(res.next()){
                Object[] dados = new Object[qtdCol];
                
                for(int i = 0; i < qtdCol; i++){
                    
                dados[i] = res.getObject(i + 1); 
                    
                }
                model.addRow(dados);
                
            }
            
           
       }catch(Exception e){
           
       JOptionPane.showMessageDialog(null, "inpossivel efectuar a connexao " + e.getMessage());
       
       }
    
    }
    
    
    
    
    
    
}

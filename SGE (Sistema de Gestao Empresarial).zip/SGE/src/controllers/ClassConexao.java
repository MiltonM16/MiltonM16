/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Milton Miquitaio
 */
public class ClassConexao {
    Connection conn = null;
    
    String url = "jdbc:mysql://localhost/sge?user=root&password=";
    //String url = "jdbc:mysql://41.94.150.22/miquitaio?user=mmiquitaio&password=mmiquitaio";
    
    public Connection conectaBD(){
        try {
            conn = DriverManager.getConnection(url);
            System.out.println("Conectado!");
            return conn;
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "Erro de Conexão: "+erro);
            return null;
        }
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.UserModel;
import view.dashboard;

/**
 *
 * @author Milton Miquitaio
 */
public class FuncionarioController {

    public void login(UserModel us) {
        String sql = "SELECT telefone, senha FROM funcionarios WHERE telefone = ? and senha = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet res = null;

        try {
            conn = new ClassConexao().conectaBD();
            stmt = conn.prepareStatement(sql);

            stmt.setString(1, us.getTelefone());
            stmt.setString(2, us.getSenha());
            res = stmt.executeQuery();

            if (res.next()) {
                
                dashboard ds = new dashboard();
                ds.setVisible(true);
                
                view.login lg = new view.login();
                lg.dispose();
                
                

            } else {

                JOptionPane.showMessageDialog(null, "Não encontrado");
            }

        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, "Erro, Não foi possível fazer o login :" + e);
        }
    }

    public void novofuncionario(UserModel model) {
        Connection conn;
        PreparedStatement pstm = null;
        ResultSet res = null;
        String sql = "insert into funcionarios (nome, nascimento, bilhete_id, nuit, nr_banco, nome_banco, senha, telefone, funcao) values(?,?,?,?,?,?,?,?,?)";

        conn = new ClassConexao().conectaBD();

        try {
            pstm = conn.prepareStatement(sql);

            pstm.setString(1, model.getNome());
            pstm.setString(2, model.getNascimento());
            pstm.setString(3, model.getBilhete_id());
            pstm.setString(4, model.getNuit());
            pstm.setString(5, model.getNr_banco());
            pstm.setString(6, model.getNome_banco());
            pstm.setString(7, model.getSenha());
            pstm.setString(8, model.getTelefone());
            pstm.setString(9, model.getFuncao());

            pstm.execute();
            pstm.close();

            JOptionPane.showMessageDialog(null, "Funcionário cadastrado com sucesso!");

        } catch (Exception erro) {
            JOptionPane.showMessageDialog(null, "Erro de Cadastro: " + erro);
        }
    }

    public void ver_funcionrios(int id) {
        try {

            Connection conn = null;
            conn = new ClassConexao().conectaBD();
            String sql = "SELECT * FROM funcionarios where id_func = ?;";

            PreparedStatement ps = null;

            ps = conn.prepareStatement(sql);
            ps.setInt(1, id);

            ResultSet res = null;

            res = ps.executeQuery();

            ResultSetMetaData rsmd = res.getMetaData();
            int qtdCol = rsmd.getColumnCount();

            while (res.next()) {
                Object[] dados = new Object[qtdCol];

                for (int i = 0; i < qtdCol; i++) {

                    dados[i] = res.getObject(i + 1);

                }
                dashboard.viewfuncnome.setText(dados[1].toString());
                dashboard.viewfuncnascimento.setText(dados[2].toString());
                dashboard.viewfuncbi.setText(dados[3].toString());
                dashboard.viewfuncnuit.setText(dados[4].toString());
                dashboard.viewfuncnrbanco.setText(dados[5].toString());
                dashboard.viewfuncnomebanco.setText(dados[6].toString());
                dashboard.viewfunctelefone.setText(dados[8].toString());
                dashboard.viewfuncfuncao.setText(dados[9].toString());
            }
            
            
            

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao listar os funcionarios " + e.getMessage());
        }

    }
    
    public void listar_funcionrios() {

        DefaultTableModel model = (DefaultTableModel) dashboard.tablefunc.getModel();
        model.setNumRows(0);
        try {

            Connection conn = null;
            conn = new ClassConexao().conectaBD();
            String sql = "SELECT id_func, nome, funcao FROM funcionarios;";

            PreparedStatement ps = null;

            ps = conn.prepareStatement(sql);

            ResultSet res = null;

            res = ps.executeQuery();

            ResultSetMetaData rsmd = res.getMetaData();
            int qtdCol = rsmd.getColumnCount();

            while (res.next()) {
                Object[] dados = new Object[qtdCol];

                for (int i = 0; i < qtdCol; i++) {

                    dados[i] = res.getObject(i + 1);

                }
                model.addRow(dados);

            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(null, "Erro ao listar os funcionarios " + e.getMessage());

        }

    }

}

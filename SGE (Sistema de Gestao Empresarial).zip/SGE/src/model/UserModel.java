/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Milton Miquitaio
 */
public class UserModel {
    private int id_func;
    private String nome;
    private String nascimento;
    private String bilhete_id;
    private String nuit;
    private String funcao;
    private String nr_banco;
    private String nome_banco;
    private String senha;
    private String telefone;

    public int getId_func() {
        return id_func;
    }

    public void setId_func(int id_func) {
        this.id_func = id_func;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNascimento() {
        return nascimento;
    }

    public void setNascimento(String nascimento) {
        this.nascimento = nascimento;
    }

    public String getBilhete_id() {
        return bilhete_id;
    }

    public void setBilhete_id(String bilhete_id) {
        this.bilhete_id = bilhete_id;
    }

    public String getNr_banco() {
        return nr_banco;
    }

    public void setNr_banco(String nr_banco) {
        this.nr_banco = nr_banco;
    }

    public String getNome_banco() {
        return nome_banco;
    }

    public void setNome_banco(String nome_banco) {
        this.nome_banco = nome_banco;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getNuit() {
        return nuit;
    }

    public void setNuit(String nuit) {
        this.nuit = nuit;
    }

    public String getFuncao() {
        return funcao;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }
    
    
    
}
